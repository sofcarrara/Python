from setuptools import setup

setup(
    name="segunda_preentrega_carrara",
    version="1.0.0",
    description="Paquete de segunda preentrega",
    author="Sofia Carrara",
    author_email="sofi.carrara2@gmail.com",
    packages=["segunda_preentrega_carrara"]
)
