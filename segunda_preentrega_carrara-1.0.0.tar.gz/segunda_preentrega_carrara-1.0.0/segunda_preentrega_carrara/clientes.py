from mi_clientes import Cliente


cliente1=Cliente(1, 'Sofia', 'Carrara', 'CalleFalsa 123','35484454315', 28)

print(cliente1)

cliente1.agregar_al_carrito('Teclado')
cliente1.agregar_al_carrito('Monitor')


cliente1.mostrar_carrito()

cliente1.vaciar_carrito()

cliente1.mostrar_carrito()
