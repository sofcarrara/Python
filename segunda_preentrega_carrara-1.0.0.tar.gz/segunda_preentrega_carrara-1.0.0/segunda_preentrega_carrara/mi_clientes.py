class Cliente():
    def __init__(self, id_cliente, nombre, apellido, direccion, telefono, edad):
        self.__id_cliente= id_cliente
        self.nombre = nombre
        self.apellido = apellido
        self.direccion = direccion
        self.telefono = telefono
        self.edad = edad
        self.carrito = []
    
    def __str__(self):
          return f"El id del cliente {self.nombre} {self.apellido} es {self.__id_cliente}. Su direccion es {self.direccion}, su telefono es {self.telefono} y tiene {self.edad} años"

    def agregar_al_carrito(self, producto):
         self.carrito.append(producto)
         print(f'El producto {producto} ha sido agregado al carrito exitosamente.')

    def mostrar_carrito(self):
        if len(self.carrito)==0:
            print(f'El carrito de {self.nombre} está vacío.')
        else:           
             print(f'Los productos en el carrito de {self.nombre} son:')
             for producto in self.carrito:
                print(f'- {producto}')

    def vaciar_carrito(self):
        self.carrito = []
        print(f'El carrito de {self.nombre} ha sido vaciado correctamente.')

